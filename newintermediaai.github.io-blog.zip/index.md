---
layout: default
title: "Home"
---

# Benvenuti nel Blog di New Intermedia AI

Analisi e approfondimenti su intelligenza artificiale, tecnologia, diritto digitale e innovazione.

---

## Ultimi Articoli

{% for post in site.posts %}
### [{{ post.title }}]({{ post.url | relative_url }})

**{{ post.date | date: "%d %B %Y" }}** | {{ post.excerpt | strip_html | truncatewords: 50 }}

{% endfor %}
