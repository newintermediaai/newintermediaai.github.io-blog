---
layout: default
title: "Chi Siamo"
---

# Chi Siamo

**New Intermedia AI** è un progetto dedicato all'analisi e alla divulgazione sulle intersezioni tra intelligenza artificiale, tecnologia e diritto.

## La nostra missione

Esploriamo come le nuove tecnologie - in particolare l'AI e la blockchain - stiano ridefinendo i confini del diritto, della proprietà intellettuale e della società digitale.

## I nostri temi

- **Intelligenza Artificiale**: impatto sul lavoro, etica, regolamentazione
- **Blockchain e registri decentralizzati**: certificazioni, proprietà digitale, smart contract
- **Diritto digitale**: privacy, proprietà intellettuale, responsabilità
- **Innovazione tecnologica**: trend, analisi, casi studio

## Contatti

Per collaborazioni o informazioni, visitate il sito principale [New Intermedia AI](https://newintermediai.github.io).
